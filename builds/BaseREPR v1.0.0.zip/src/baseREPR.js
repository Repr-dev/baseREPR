/*
        ____                 _____  ______ _____  _____  
    |  _ \               |  __ \|  ____|  __ \|  __ \ 
    | |_) | __ _ ___  ___| |__) | |__  | |__) | |__) |
    |  _ < / _` / __|/ _ \  _  /|  __| |  ___/|  _  / 
    | |_) | (_| \__ \  __/ | \ \| |____| |    | | \ \ 
    |____/ \__,_|___/\___|_|  \_\______|_|    |_|  \_\
    BaseREPR                                            


    Made by REPR ----- January 28-29, 2025

    This script has two modes--CMD and WEB.
    CMD is for use with NodeJS in the command prompt and WEB is for use on the web.

    To enable CMD for execution with NodeJS:
    - Uncomment the "prompt-sync" line below
    - Ensure "enactPromptsCMD()" is used instead of "enactPromptsWEB()" (see the bottom of the file)

    To enable WEB for execution as an HTML <script> tag:
    - Ensure "enactPromptsWEB()" is used rather than "enactPromptsCMD()" (see the bottom of the file)

*/

// CMD ONLY
// const prompt = require("prompt-sync")();

(() => {

let ogS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-._+!'(%,$/:=*;)?<>@&^%|[]{} `#\\~\t\n"; // Base 97
let s;

function setupSWithKey(keyText) {
    const startSArr = ogS.split("");
    const k = (() => {
        let finalKey = [];
        for(let i = 0; i < keyText.length; i++) {
        finalKey.push(ogS.indexOf(keyText[i]));
        }
    
        return finalKey.join("");
    })();
    
    for(let i = 0; i < startSArr.length; i++) {
        let timesToShift = (i * k) % startSArr.length;
    
        let elm = startSArr.splice(i, 1)[0];
        startSArr.splice(i + timesToShift, 0, elm);
    }

    for(let i = startSArr.length; i > 0; i--) {
        let timesToShift = (i * k) % startSArr.length;
    
        let elm = startSArr.splice(i, 1)[0];
        startSArr.splice(i + timesToShift, 0, elm);
    }
    
    if((keyText % 2) == 0) startSArr.reverse();
    
    return startSArr.join("");
}

function plaintextToCiphertext(plaintxt) {
    let ptArr = plaintxt.split("").reverse();
    let newArr = [];
    
    for(let i = 0; i < ptArr.length; i++) {
        newArr.push(s[ogS.indexOf(ptArr[i])]);
    }
    
    return btoa(newArr.join(""));
}
function ciphertextToPlaintext(ciphertxt) {
    ciphertxt = atob(ciphertxt);
    let ctArr = ciphertxt.split("");
    
    for(let i = 0; i < ctArr.length; i++) {
        ctArr[i] = ogS[s.indexOf(ctArr[i])];
    }
    
    return ctArr.reverse().join("");
}

function enactPromptsWEB() {
    function resetPage() {
        if(!document.hidden) {
            location.reload();
        }
        else {
            setInterval(() => {
                if(!document.hidden) location.reload();
            }, 50);
        }
    }

    let mode = prompt("Would you like to ENCODE (type \"e\") or DECODE (type \"d\")? > ");
    if(mode === "e") {
        let plaintext = prompt("Text to encode? > ");
        if(plaintext === null) {
            resetPage();
            return;
        }

        let key = prompt("Encryption/Decryption key? (only you and the recipient should know this) > ");
        if(key === null) {
            resetPage();
            return;
        }

        s = setupSWithKey(key);

        let ciphertext = plaintextToCiphertext(plaintext);

        alert(
            `----- ENCRYPTION RESULT -----\n\nCiphertext: ${ciphertext}\nPlaintext: ${plaintext}\nKey: ${key}`
        );
        resetPage();
    }
    else if(mode === "d") {
        let ciphertext = prompt("Text to decode? (take care to get everything correct) > ");
        if(ciphertext === null) {
            resetPage();
            return;
        }

        let key = prompt("Decryption key? > ");
        if(key === null) {
            resetPage();
            return;
        }

        s = setupSWithKey(key);

        let plaintext = ciphertextToPlaintext(ciphertext);

        alert(
            `----- DECRYPTION RESULT -----\n\nPlaintext: ${plaintext}\nCiphertext: ${ciphertext}\nKey Used: ${key}`
        );
        resetPage();
    }
    else if(mode === null) {
        resetPage();
    }
    else if(mode === undefined) {
        document.addEventListener("focus", e => {
            resetPage();
        });
    }
    else {
        alert("Invalid response. Must type \"e\" or \"d\".");
        resetPage();
    }
}
function enactPromptsCMD() {
    let mode = prompt("Would you like to ENCODE (type \"e\") or DECODE (type \"d\")? > ");
    if(mode === "e") {
        let plaintext = prompt("Text to encode? > ");
        let key = prompt("Encryption/Decryption key? (only you and the recipient should know this) > ");
        s = setupSWithKey(key);

        let ciphertext = plaintextToCiphertext(plaintext);

        console.log(
            `\n----- ENCRYPTION RESULT -----\n\nCiphertext: ${ciphertext}\nPlaintext: ${plaintext}\nKey: ${key}\n`
        );
    }
    else if(mode === "d") {
        let ciphertext = prompt("Text to decode? (take care to get everything correct) > ");
        let key = prompt("Decryption key? > ");
        s = setupSWithKey(key);

        let plaintext = ciphertextToPlaintext(ciphertext);

        console.log(
            `\n----- DECRYPTION RESULT -----\n\nPlaintext: ${plaintext}\nCiphertext: ${ciphertext}\nKey Used: ${key}\n`
        );
    }
    else {
        console.log("Invalid response. Must type \"e\" or \"d\".\n");
    }
}

// enactPromptsCMD();
enactPromptsWEB();

})();